# WebGoat landing page

Old GitHub page which now redirects to OWASP website.

